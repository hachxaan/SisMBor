create
    definer = admin@`%` procedure StpActualizaConceptoStock(IN peCVE_OPERACION varchar(8), IN ID_CONCEPTO_PUT int,
                                                            IN peCANTIDAD int, OUT psCOD_RESP int,
                                                            OUT psSTR_RESP varchar(128))
StpMain:
BEGIN
	DECLARE vSTOCK INT;
	DECLARE vSTOCK_set INT;
	DECLARE vEXCEPTION_MSG VARCHAR(512);
    DECLARE vDESC_CONCEPTO VARCHAR(128);
	DECLARE vNoHandleRegistro			BOOLEAN DEFAULT FALSE; 

	DECLARE cuCONCEPTO
	  CURSOR FOR (
			SELECT STOCK
			FROM concepto
			WHERE ID_CONCEPTO = ID_CONCEPTO_PUT); 

	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
		@errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
		
        SET @full_error = CONCAT('StpActualizaConceptoStock: ERROR ', @errno, ' (', @sqlstate, '): ', @text);
        CALL `debug`(@full_error);
		SET psSTR_RESP = @text;
        SET psCOD_RESP = @errno;
		
		IF psCOD_RESP = 1452 THEN
			SET psSTR_RESP = CONCAT('Error de llave foranea -> ','(Field:', SUBSTRING( psSTR_RESP, LOCATE('FOREIGN KEY (', psSTR_RESP) + 12,  100  ));
		END IF;
	END; 
	SET psSTR_RESP = '';
	
	
	
       

    OPEN cuCONCEPTO;
		FETCH cuCONCEPTO INTO vSTOCK;							
	CLOSE cuCONCEPTO;
    

	IF (peCVE_OPERACION = 'ENTRADA') THEN
		SET vSTOCK_set = vSTOCK + peCANTIDAD;
	ELSE
		SET vSTOCK_set = (vSTOCK - peCANTIDAD);                    
	END IF;   
        
	IF vSTOCK_set < 0 THEN
			SELECT DESC_CONCEPTO 
			INTO vDESC_CONCEPTO
			FROM concepto
			WHERE ID_CONCEPTO = ID_CONCEPTO_PUT;
	
		SET vEXCEPTION_MSG = CONCAT(  'Sin existencia en inventario. ',
					 'Se quiere dar salida a ', CAST(peCANTIDAD  AS CHAR), ' y solo existen ',
					 'en inventario ' , CAST(vSTOCK AS CHAR ) ) ;
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = vEXCEPTION_MSG;
	ELSE
		UPDATE concepto SET STOCK = vSTOCK_set
		WHERE ID_CONCEPTO = ID_CONCEPTO_PUT;	       
	END IF;

	SET psCOD_RESP = 0;
	SET psSTR_RESP = 'OK';        

END StpMain;

