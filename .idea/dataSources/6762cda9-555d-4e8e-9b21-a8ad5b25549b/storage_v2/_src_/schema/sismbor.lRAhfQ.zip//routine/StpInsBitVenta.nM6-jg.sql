create
    definer = admin@`%` procedure StpInsBitVenta(IN peID_CONCEPTO int, IN peCVE_USUARIO varchar(8), IN peFOLIO int,
                                                 IN peID_PERSONAL int, IN peTX_REFERENCIA varchar(128),
                                                 IN peCANTIDAD int, IN peIMP_TRANS decimal(18, 2),
                                                 IN peCVE_OPERACION varchar(16), IN peFUERZASALIDA varchar(1),
                                                 IN peID_ORDEN_DETALLE int, OUT psCOD_RESP int,
                                                 OUT psSTR_REST varchar(128))
BEGIN

  INSERT INTO `bit_venta`
				(
				`ID_CONCEPTO`,
				`IMP_TRANS`,
				`FH_REGISTRO`,
				`CVE_USUARIO`,
				`ID_PERSONAL`,
				`FOLIO`,
				`TX_REFERENCIA`,
				`CVE_OPERACION`,
				`CANTIDAD`,
				`FUERZASALIDA`,
                `ID_ORDEN_DETALLE`)
				VALUES
				(peID_CONCEPTO,
				peIMP_TRANS,
				CURRENT_TIMESTAMP,
				peCVE_USUARIO,
				peID_PERSONAL,
				peFOLIO,
				peTX_REFERENCIA,
				peCVE_OPERACION,
				peCANTIDAD,
				peFUERZASALIDA,
                peID_ORDEN_DETALLE
                );

   
  SET psSTR_REST = 'OK'; 
  SET psCOD_RESP = 0;


END;

