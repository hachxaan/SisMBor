create definer = admin@`%` trigger orden_detalle_AFTER_INSERT
    after insert
    on orden_detalle
    for each row
BEGIN
	
    SELECT ID_TIPO_CONCEPTO
		INTO @ID_TIPO_CONCEPTO
		FROM concepto
		WHERE ID_CONCEPTO = NEW.ID_CONCEPTO;
    
    SELECT CVE_OPERACION 
		INTO @CVE_OPERACION
		FROM concepto_tipo
		WHERE ID_TIPO_CONCEPTO = @ID_TIPO_CONCEPTO;

    CALL `debug`('orden_detalle_AFTER_INSERT -> StpInsBitVenta...');
    
    CALL `debug`(CONCAT('NEW.ID_ORDEN_DETALLE', NEW.ID_ORDEN_DETALLE));
    
    CALL `StpInsBitVenta`(	NEW.ID_CONCEPTO, 
							NEW.CVE_USU_ALTA, 
							NEW.FOLIO, 
							NEW.ID_PERSONAL, 
							NEW.TX_REFERENCIA, 
							NEW.CANTIDAD, 
							NEW.PRECIO_VENTA, 
							@CVE_OPERACION , 
							'F', 
                            NEW.ID_ORDEN_DETALLE,
							@psCOD_RESP, 
							@psSTR_RESP);
END;

