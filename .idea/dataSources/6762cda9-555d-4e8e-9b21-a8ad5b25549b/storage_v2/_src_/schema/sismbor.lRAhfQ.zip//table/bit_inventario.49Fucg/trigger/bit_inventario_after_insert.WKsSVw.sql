create definer = admin@`%` trigger bit_inventario_AFTER_INSERT
    after insert
    on bit_inventario
    for each row
BEGIN
	CALL `debug`('bit_inventario_AFTER_INSERT -> trigger_BitInventario_AI...');
    CALL `debug`(NEW.ID_CONCEPTO);
    
	CALL `trigger_BitInventario_AI`(
								NEW.ID_CONCEPTO,
								NEW.CANTIDAD,
								NEW.CVE_OPERACION,
								NEW.PRECIO_COMPRA);

END;

