create view w_cuenta_abierta as
select `ord`.`FOLIO`                                                                 AS `Folio`,
       ''                                                                            AS `INFO`,
       `cte`.`NOMBRE_EMPRESA`                                                        AS `Cliente`,
       `cta`.`IMP_TOTAL`                                                             AS `Cuenta`,
       concat('S/.', format(`cta`.`IMP_TOTAL`, 2))                                   AS `CUENTA_FORMATO`,
       date_format(`ord`.`FH_ALTA`, '%d/%m/%Y %H:%i:%s')                             AS `FH_REGISTRO`,
       date_format(`ord`.`FH_INICIO`, '%d/%m/%Y %H:%i:%s')                           AS `FH_INICIO`,
       date_format(`ord`.`FH_SALIDA`, '%d/%m/%Y %H:%i:%s')                           AS `FH_SALIDA`,
       date_format(`ord`.`FH_CANCELA`, '%d/%m/%Y %H:%i:%s')                          AS `FH_CANCELA`,
       date_format(`uni`.`FH_REGISTRO`, '%d/%m/%Y %H:%i:%s')                         AS `FH_REGISTRO_UNIDAD`,
       (case
            when (date_format(`ord`.`FH_ULTIMO_SERVICIO`, '%d/%m/%Y %H:%i:%s') is null) then ''
            else date_format(`ord`.`FH_ULTIMO_SERVICIO`, '%d/%m/%Y %H:%i:%s') end)   AS `FH_ULTIMO_SERVICIO`,
       `ord`.`STATUS`                                                                AS `STATUS`,
       (case `ord`.`STATUS`
            when 0 then 'PENDIENTE'
            when 1 then 'TRABAJADO'
            when 2 then 'TERMINADO'
            when 3 then 'CANCELAD0' end)                                             AS `DESC_STATUS`,
       `ord`.`CVE_USU_ALTA`                                                          AS `USU_ALTA`,
       `cta`.`DESCUENTO_CUENTA`                                                      AS `DESCUENTO_CUENTA`,
       `cte`.`ID_CLIENTE`                                                            AS `ID_CLIENTE`,
       `uni`.`PLACA`                                                                 AS `PLACA`,
       `ord`.`KILOMETRAJE`                                                           AS `KILOMETRAJE`,
       `ord`.`NOMBRE_ENTREGA`                                                        AS `NOMBRE_ENTREGA`,
       (case when (`ord`.`KM_ANTERIOR` is null) then 0 else `ord`.`KM_ANTERIOR` end) AS `KM_ANTERIOR`,
       `ord`.`FOLIO_ULTIMA_ORDEN`                                                    AS `FOLIO_ULTIMA_ORDEN`,
       `uni`.`MARCA`                                                                 AS `MARCA`,
       `uni`.`MODELO`                                                                AS `MODELO`,
       `uni`.`MOTOR`                                                                 AS `MOTOR`,
       `uni`.`CHASIS`                                                                AS `CHASIS`,
       (select count(1)
        from `sismbor`.`orden_detalle` `od`
        where ((`od`.`FOLIO` = `cta`.`FOLIO`) and (`od`.`SIT_CODE` <> 'CA')))        AS `NO_CONCEPTOS`
from (((`sismbor`.`cuenta` `cta` left join `sismbor`.`orden` `ord` on ((`ord`.`FOLIO` = `cta`.`FOLIO`))) left join `sismbor`.`unidad` `uni` on ((`uni`.`ID_UNIDAD` = `ord`.`ID_UNIDAD`)))
         left join `sismbor`.`cliente` `cte` on ((`cte`.`ID_CLIENTE` = `uni`.`ID_CLIENTE`)))
order by `ord`.`FOLIO`;

