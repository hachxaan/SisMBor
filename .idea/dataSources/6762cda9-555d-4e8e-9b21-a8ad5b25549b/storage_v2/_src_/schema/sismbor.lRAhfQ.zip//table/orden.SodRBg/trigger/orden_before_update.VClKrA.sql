create definer = admin@`%` trigger orden_BEFORE_UPDATE
    before update
    on orden
    for each row
BEGIN
	IF (NEW.STATUS <> OLD.STATUS) THEN
		CASE NEW.STATUS 
			WHEN 1 THEN 
				SET NEW.FH_INICIO = CURRENT_TIMESTAMP;
			WHEN 2 THEN
				SET NEW.FH_SALIDA = CURRENT_TIMESTAMP;
			WHEN 3 THEN 
				SET NEW.FH_CANCELA = CURRENT_TIMESTAMP;
		END CASE;    
    END IF;
END;

