create definer = admin@`%` trigger orden_detalle_AFTER_UPDATE
    after update
    on orden_detalle
    for each row
BEGIN
	IF ((NEW.SIT_CODE = 'CA') AND  (NEW.SIT_CODE <> OLD.SIT_CODE ) ) THEN
		CALL tigger_OrdenDetalle_AU(OLD.ID_ORDEN_DETALLE);
	END IF;
    CALL `debug`('1');
    IF (NEW.TX_REFERENCIA IS NOT NULL) THEN
    CALL `debug`('2');
		IF (NEW.TX_REFERENCIA <> 	IFNULL(OLD.TX_REFERENCIA,'') ) THEN
		CALL `debug`('3');
			CALL tigger_OrdenDetalle_TX_REFERENCIA_AU(OLD.ID_ORDEN_DETALLE, NEW.TX_REFERENCIA);
		END IF;
	END IF;
END;

