create view w_conceptos_main as
select `sismbor`.`concepto`.`ID_CONCEPTO`                                                                           AS `ID_CONCEPTO`,
       `sismbor`.`concepto`.`CVE_CONCEPTO`                                                                          AS `CVE_CONCEPTO`,
       `sismbor`.`concepto`.`DESC_CONCEPTO`                                                                         AS `DESC_CONCEPTO`,
       `sismbor`.`concepto`.`ID_TIPO_SERVICIO`                                                                      AS `ID_TIPO_SERVICIO`,
       `sismbor`.`tipo_servicio`.`DESC_TIPO_SERVICIO`                                                               AS `DESC_TIPO_SERVICIO`,
       `sismbor`.`concepto`.`ID_TIPO_CONCEPTO`                                                                      AS `ID_TIPO_CONCEPTO`,
       `sismbor`.`concepto`.`ID_CATEGORIA`                                                                          AS `ID_CATEGORIA`,
       `sismbor`.`concepto_tipo`.`DESC_TIPO_CONCEPTO`                                                               AS `DESC_TIPO_CONCEPTO`,
       `sismbor`.`concepto_categoria`.`DESC_CATEGORIA`                                                              AS `DESC_CATEGORIA`,
       `sismbor`.`concepto`.`ID_UNIDAD_MEDIDA`                                                                      AS `ID_UNIDAD_MEDIDA`,
       `sismbor`.`unidad_medida`.`ABREB_UNIDAD_MEDIDA`                                                              AS `ABREB_UNIDAD_MEDIDA`,
       `sismbor`.`concepto`.`ID_PERIODO_KM`                                                                         AS `ID_PERIODO_KM`,
       `sismbor`.`periodo_km`.`KILOMETRAJE`                                                                         AS `KILOMETRAJE`,
       `sismbor`.`periodo_km`.`DESC_PERIODO_KM`                                                                     AS `DESC_PERIODO_KM`,
       `sismbor`.`concepto`.`ID_MARCA`                                                                              AS `ID_MARCA`,
       `sismbor`.`concepto_tipo_marca`.`DESC_MARCA`                                                                 AS `DESC_MARCA`,
       `sismbor`.`concepto`.`PRECIO_VENTA`                                                                          AS `PRECIO_VENTA`,
       `sismbor`.`concepto`.`VIDA_UTIL_KM`                                                                          AS `VIDA_UTIL_KM`,
       `sismbor`.`concepto`.`VIDA_UTIL_HR`                                                                          AS `VIDA_UTIL_HR`,
       `sismbor`.`concepto`.`DESCUENTO`                                                                             AS `DESCUENTO`,
       `sismbor`.`concepto`.`HORA_HOMBRE`                                                                           AS `HORA_HOMBRE`,
       `sismbor`.`concepto`.`CVE_USU_ALTA`                                                                          AS `CVE_USU_ALTA`,
       `sismbor`.`concepto`.`NO_SERIE`                                                                              AS `NO_SERIE`,
       `sismbor`.`concepto`.`STOCK`                                                                                 AS `STOCK`,
       `sismbor`.`concepto`.`CVE_CONCEPTO`                                                                          AS `CLAVE_SEL`,
       `sismbor`.`concepto`.`B_NUMERO_SERIE`                                                                        AS `B_NUMERO_SERIE`,
       `sismbor`.`concepto`.`B_NSERIE_OBLIGATORIO`                                                                  AS `B_NSERIE_OBLIGATORIO`,
       (case
            when (`sismbor`.`concepto`.`B_NUMERO_SERIE` = 1) then 'SI'
            else 'NO' end)                                                                                          AS `BS_NUMERO_SERIE`,
       (case
            when (`sismbor`.`concepto`.`B_NUMERO_SERIE` = 1) then (case
                                                                       when (`sismbor`.`concepto`.`B_NSERIE_OBLIGATORIO` = 1)
                                                                           then 'SI'
                                                                       else 'NO' end)
            else 'NA' end)                                                                                          AS `BS_NSERIE_OBLIGATORIO`,
       `sismbor`.`concepto`.`PRECIO_COMPRA`                                                                         AS `PRECIO_COMPRA`,
       concat(`sismbor`.`concepto`.`CVE_CONCEPTO`, ' ', `sismbor`.`concepto`.`DESC_CONCEPTO`, ' ',
              `sismbor`.`concepto_tipo`.`DESC_TIPO_CONCEPTO`, ' ',
              `sismbor`.`concepto_categoria`.`DESC_CATEGORIA`)                                                      AS `DESCRIPCION`,
       `sismbor`.`operacion`.`AF_INVENTARIO`                                                                        AS `AF_INVENTARIO`,
       `sismbor`.`concepto_tipo`.`CVE_OPERACION`                                                                    AS `CVE_OPERACION`,
       `sismbor`.`concepto_tipo`.`B_PERSONAL`                                                                       AS `B_PERSONAL`,
       `sismbor`.`concepto`.`B_AGREGA_CONCEPTOS`                                                                    AS `B_AGREGA_CONCEPTOS`
from (((((((`sismbor`.`concepto` left join `sismbor`.`concepto_tipo` on ((`sismbor`.`concepto_tipo`.`ID_TIPO_CONCEPTO` =
                                                                          `sismbor`.`concepto`.`ID_TIPO_CONCEPTO`))) left join `sismbor`.`tipo_servicio` on ((
        `sismbor`.`tipo_servicio`.`ID_TIPO_SERVICIO` =
        `sismbor`.`concepto`.`ID_TIPO_SERVICIO`))) left join `sismbor`.`concepto_categoria` on ((
        `sismbor`.`concepto_categoria`.`ID_CATEGORIA` =
        `sismbor`.`concepto`.`ID_CATEGORIA`))) left join `sismbor`.`operacion` on ((
        `sismbor`.`operacion`.`CVE_OPERACION` =
        `sismbor`.`concepto_tipo`.`CVE_OPERACION`))) left join `sismbor`.`unidad_medida` on ((
        `sismbor`.`unidad_medida`.`ID_UNIDAD_MEDIDA` =
        `sismbor`.`concepto`.`ID_UNIDAD_MEDIDA`))) left join `sismbor`.`periodo_km` on ((
        `sismbor`.`periodo_km`.`ID_PERIODO_KM` = `sismbor`.`concepto`.`ID_PERIODO_KM`)))
         left join `sismbor`.`concepto_tipo_marca` on (((`sismbor`.`concepto_tipo_marca`.`ID_TIPO_CONCEPTO` =
                                                         `sismbor`.`concepto`.`ID_TIPO_CONCEPTO`) and
                                                        (`sismbor`.`concepto_tipo_marca`.`ID_MARCA` =
                                                         `sismbor`.`concepto`.`ID_MARCA`))))
order by `sismbor`.`concepto`.`ID_TIPO_CONCEPTO`, `sismbor`.`concepto`.`DESC_CONCEPTO`;

