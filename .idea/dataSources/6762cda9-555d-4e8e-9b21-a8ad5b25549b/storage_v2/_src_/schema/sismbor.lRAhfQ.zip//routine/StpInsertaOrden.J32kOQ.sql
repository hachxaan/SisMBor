create
    definer = admin@`%` procedure StpInsertaOrden(IN peID_UNIDAD varchar(32), IN peKILOMETRAJE varchar(32),
                                                  IN peCVE_USU_ALTA varchar(16), IN peNOMBRE_ENTREGA varchar(64),
                                                  IN peTX_REFERENCIA varchar(512), OUT psSTR_RESP varchar(512))
BEGIN
	 DECLARE vFOLIO INT;
     DECLARE vID_CUENTA INT;

	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		ROLLBACK;

        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
		 @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;


		SET @full_error = CONCAT("ERROR ", @errno, " (", @sqlstate, "): ", @text);
		CALL `debug`(@full_error);
        
		SET psSTR_RESP = @full_error;
		  
		
	END;	
    
        
    
    SELECT MAX(FOLIO)
    INTO @FOLIO_ULTIMA_ORDEN
    FROM `orden`
    WHERE ID_UNIDAD = peID_UNIDAD
      AND STATUS = 2; -- TERMINADA
    
    
    
    IF ( @FOLIO_ULTIMA_ORDEN IS NOT NULL ) THEN
		
		SELECT FH_SALIDA, KILOMETRAJE
		INTO @FH_ULTIMO_SERVICIO, @KM_ANTERIOR
		FROM `orden`
		WHERE FOLIO = @FOLIO_ULTIMA_ORDEN
          AND STATUS = 2;
        
	ELSE
		SET @FH_ULTIMO_SERVICIO = NULL;
        SET @KM_ANTERIOR = NULL;
    END IF;
    
    
	INSERT INTO `orden`
		(
		`ID_UNIDAD`,
		`KILOMETRAJE`,
		`CVE_USU_ALTA`,
		`FH_ALTA`,
		`NOMBRE_ENTREGA`,
        `KM_ANTERIOR`,
		`FH_ULTIMO_SERVICIO`,
		`FOLIO_ULTIMA_ORDEN`
        )
		VALUES
		(
		peID_UNIDAD,
		peKILOMETRAJE,
		peCVE_USU_ALTA,
		CURRENT_TIMESTAMP,
		peNOMBRE_ENTREGA,
        @KM_ANTERIOR,
        @FH_ULTIMO_SERVICIO,
        @FOLIO_ULTIMA_ORDEN);

	SELECT LAST_INSERT_ID() INTO vFOLIO;

	INSERT INTO `cuenta`
			(`FOLIO`)
			VALUES (vFOLIO);
	SELECT LAST_INSERT_ID() INTO vID_CUENTA;
    
    IF (peTX_REFERENCIA <> '' ) THEN
		INSERT INTO `orden_referencias`
			(
			`FOLIO`,
			`TX_REFERENCIA`,
			`CVE_USUARIO_ALTA`,
			`FH_REGISTRO`)
			VALUES
			(
			vFOLIO,
			peTX_REFERENCIA,
			peCVE_USU_ALTA,
			CURRENT_TIMESTAMP);
	END IF;

   SET psSTR_RESP = JSON_OBJECT('psFOLIO', vFOLIO, 'psID_CUENTA',  vID_CUENTA);      
  
END;

