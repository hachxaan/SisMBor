create
    definer = admin@`%` procedure tigger_OrdenDetalle_TX_REFERENCIA_AU(IN peID_ORDEN_DETALLE int, IN peTX_REFERENCIA varchar(1024))
BEGIN
CALL `debug`('4');
	UPDATE `bit_inventario`
    SET TX_REFERENCIA = peTX_REFERENCIA
    WHERE ID_ORDEN_DETALLE = peID_ORDEN_DETALLE;
END;

