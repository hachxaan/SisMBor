create view w_tipo_combustible as
select 1 AS `ID_TIPO_COMBUSTIBLE`, 'DISEL' AS `DESC_TIPO_COMBUSTIBLE`
union
select 2 AS `ID_TIPO_COMBUSTIBLE`, 'GNV' AS `DESC_TIPO_COMBUSTIBLE`;

