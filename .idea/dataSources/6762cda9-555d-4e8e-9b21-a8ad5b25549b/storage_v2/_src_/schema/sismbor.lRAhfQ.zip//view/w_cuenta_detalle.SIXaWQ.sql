create view w_cuenta_detalle as
select `b`.`ID_TRANS_VENTA`                                                                             AS `ID_TRANS_VENTA`,
       `b`.`CANTIDAD`                                                                                   AS `CANTIDAD`,
       `p`.`CVE_CONCEPTO`                                                                               AS `CVE_CONCEPTO`,
       `p`.`DESC_CONCEPTO`                                                                              AS `DESC_CONCEPTO`,
       (case when (`o`.`AF_TOTAL_CUENTA` = 'D') then (`b`.`IMP_TRANS` * -(1)) else `b`.`IMP_TRANS` end) AS `PRECIO`,
       ((case when (`o`.`AF_TOTAL_CUENTA` = 'D') then (`b`.`IMP_TRANS` * -(1)) else `b`.`IMP_TRANS` end) *
        `b`.`CANTIDAD`)                                                                                 AS `IMPORTE`,
       ((case when (`o`.`AF_TOTAL_CUENTA` = 'D') then 0 else `b`.`IMP_TRANS` end) * `b`.`CANTIDAD`)     AS `SUBTOTAL`,
       concat(`a`.`NOMBRE`, ' ', `a`.`APELLIDO`)                                                        AS `AGENTE`,
       `b`.`TX_REFERENCIA`                                                                              AS `TX_REFERENCIA`,
       `b`.`FH_REGISTRO`                                                                                AS `FH_REGISTRO`,
       `ord`.`FOLIO`                                                                                    AS `FOLIO`,
       `b`.`ID_PERSONAL`                                                                                AS `ID_PERSONAL`,
       `b`.`ID_TRANS_INVENTARIO`                                                                        AS `ID_TRANS_INVENTARIO`,
       `ct`.`DESC_TIPO_CONCEPTO`                                                                        AS `TIPO_VENTA`,
       `b`.`STATUS`                                                                                     AS `STATUS`,
       (case when (`o`.`AF_TOTAL_CUENTA` = 'D') then (`b`.`IMP_TRANS` * `b`.`CANTIDAD`) else 0 end)     AS `DESCUENTO`,
       `p`.`ID_TIPO_CONCEPTO`                                                                           AS `ID_TIPO_CONCEPTO`,
       `p`.`ID_TIPO_SERVICIO`                                                                           AS `ID_TIPO_SERVICIO`,
       `sismbor`.`tipo_servicio`.`DESC_TIPO_SERVICIO`                                                   AS `DESC_TIPO_SERVICIO`
from ((((((`sismbor`.`bit_venta` `b` left join `sismbor`.`orden` `ord` on ((`ord`.`FOLIO` = `b`.`FOLIO`))) left join `sismbor`.`concepto` `p` on ((`p`.`ID_CONCEPTO` = `b`.`ID_CONCEPTO`))) left join `sismbor`.`concepto_tipo` `ct` on ((`ct`.`ID_TIPO_CONCEPTO` = `p`.`ID_TIPO_CONCEPTO`))) left join `sismbor`.`personal` `a` on ((`a`.`ID_PERSONAL` = `b`.`ID_PERSONAL`))) left join `sismbor`.`operacion` `o` on ((`o`.`CVE_OPERACION` = `b`.`CVE_OPERACION`)))
         left join `sismbor`.`tipo_servicio`
                   on ((`sismbor`.`tipo_servicio`.`ID_TIPO_SERVICIO` = `p`.`ID_TIPO_SERVICIO`)))
order by `b`.`ID_TRANS_VENTA`;

