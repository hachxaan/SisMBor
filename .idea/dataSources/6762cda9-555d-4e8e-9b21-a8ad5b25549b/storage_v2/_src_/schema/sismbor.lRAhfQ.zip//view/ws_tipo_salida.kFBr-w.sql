create view ws_tipo_salida as
select row_number() OVER (ORDER BY `sismbor`.`operacion`.`CVE_OPERACION` )                          AS `id`,
       `sismbor`.`operacion`.`CVE_OPERACION`                                                        AS `CVE_OPERACION`,
       concat(`sismbor`.`operacion`.`CVE_OPERACION`, ' - ', `sismbor`.`operacion`.`DESC_OPERACION`) AS `DESCRIPCION`,
       `sismbor`.`operacion`.`DESC_OPERACION`                                                       AS `DESC_OPERACION`
from `sismbor`.`operacion`
where ((`sismbor`.`operacion`.`AF_INVENTARIO` = 'D') and (`sismbor`.`operacion`.`AF_CAJA` = 'N') and
       (`sismbor`.`operacion`.`AF_TOTAL_CUENTA` = 'N') and (`sismbor`.`operacion`.`ACTIVO` = 1));

