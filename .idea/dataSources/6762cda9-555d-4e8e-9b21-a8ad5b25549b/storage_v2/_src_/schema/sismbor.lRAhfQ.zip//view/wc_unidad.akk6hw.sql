create view wc_unidad as
select `u`.`ID_CLIENTE`         AS `ID_CLIENTE`,
       `u`.`PLACA`              AS `PLACA`,
       `u`.`MARCA`              AS `MARCA`,
       `u`.`MODELO`             AS `MODELO`,
       `u`.`MOTOR`              AS `MOTOR`,
       `u`.`CHASIS`             AS `CHASIS`,
       `u`.`FH_REGISTRO`        AS `FH_REGISTRO`,
       `c`.`RUP`                AS `RUP`,
       `c`.`NOMBRE_EMPRESA`     AS `NOMBRE_EMPRESA`,
       `c`.`TELEFONO_CONTACTO`  AS `TELEFONO_CONTACTO`,
       `c`.`CELULAR_CONTACTO`   AS `CELULAR_CONTACTO`,
       `c`.`CORREO_ELECTRONICO` AS `CORREO_ELECTRONICO`,
       `c`.`DIRECCION`          AS `DIRECCION`,
       `c`.`NOMBRE`             AS `NOMBRE`,
       `c`.`APELLIDO`           AS `APELLIDO`,
       `c`.`CVE_USU_ALTA`       AS `CVE_USU_ALTA_CLIENTE`,
       `c`.`FH_REGISTRO`        AS `FH_REGISTRO_CLIENTE`,
       `cr`.`FOLIO`             AS `FOLIO_CURRENT`,
       `f`.`FOLIO`              AS `FOLIO`,
       `f`.`ID_UNIDAD`          AS `ID_UNIDAD`,
       `f`.`KILOMETRAJE`        AS `KILOMETRAJE`,
       `f`.`CVE_USU_ALTA`       AS `CVE_USU_ALTA`,
       `f`.`FH_ALTA`            AS `FH_ALTA`,
       `f`.`FH_INICIO`          AS `FH_INICIO`,
       `f`.`FH_SALIDA`          AS `FH_SALIDA`,
       `f`.`NOMBRE_ENTREGA`     AS `NOMBRE_ENTREGA`,
       `f`.`STATUS`             AS `STATUS`,
       `f`.`FH_CANCELA`         AS `FH_CANCELA`,
       `f`.`KM_ANTERIOR`        AS `KM_ANTERIOR`,
       `f`.`FH_ULTIMO_SERVICIO` AS `FH_ULTIMO_SERVICIO`,
       `f`.`FOLIO_ULTIMA_ORDEN` AS `FOLIO_ULTIMA_ORDEN`
from ((((`sismbor`.`unidad` `u` join `sismbor`.`cliente` `c`) left join (select `sismbor`.`orden`.`ID_UNIDAD`  AS `ID_UNIDAD`,
                                                                                max(`sismbor`.`orden`.`FOLIO`) AS `FOLIO`
                                                                         from `sismbor`.`orden`
                                                                         where (`sismbor`.`orden`.`STATUS` = 2)
                                                                         group by `sismbor`.`orden`.`ID_UNIDAD`) `mx` on ((`u`.`ID_UNIDAD` = `mx`.`ID_UNIDAD`))) left join (select `sismbor`.`orden`.`ID_UNIDAD`  AS `ID_UNIDAD`,
                                                                                                                                                                                   max(`sismbor`.`orden`.`FOLIO`) AS `FOLIO`
                                                                                                                                                                            from `sismbor`.`orden`
                                                                                                                                                                            where (`sismbor`.`orden`.`STATUS` in (0, 1))
                                                                                                                                                                            group by `sismbor`.`orden`.`ID_UNIDAD`) `cr` on ((`u`.`ID_UNIDAD` = `cr`.`ID_UNIDAD`)))
         left join `sismbor`.`orden` `f` on ((`f`.`FOLIO` = `mx`.`FOLIO`)))
where (`u`.`ID_CLIENTE` = `c`.`ID_CLIENTE`);

