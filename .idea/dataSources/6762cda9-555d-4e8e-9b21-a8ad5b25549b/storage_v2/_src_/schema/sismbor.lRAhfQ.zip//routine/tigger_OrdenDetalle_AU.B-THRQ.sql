create
    definer = admin@`%` procedure tigger_OrdenDetalle_AU(IN peID_ORDEN_DETALLE int)
BEGIN
	SELECT ID_TRANS_VENTA
    INTO @ID_TRANS_VENTA
    FROM bit_venta
    WHERE ID_ORDEN_DETALLE = peID_ORDEN_DETALLE;
	UPDATE bit_venta SET STATUS = 0 WHERE ID_TRANS_VENTA = @ID_TRANS_VENTA;
END;

