create
    definer = admin@`%` procedure trigger_BitVenta_AU(IN peID_CONCEPTO_OLD int, IN peCVE_OPERACION_OLD varchar(32),
                                                      IN peFOLIO_OLD int, IN peIMP_TRANS_OLD decimal(18, 2),
                                                      IN peCVE_USUARIO varchar(32), IN peCANTIDAD_OLD decimal(18, 2),
                                                      IN peTX_REFERENCIA varchar(512), IN peSTATUS int,
                                                      IN peSTATUS_OLD int, IN peID_ORDEN_DETALLE int)
BEGIN
	DECLARE vCodResp INTEGER;
	DECLARE vStrResp VARCHAR(128);
	DECLARE vIdTransInventario INTEGER;
	DECLARE vAF_INVENTARIO VARCHAR(8);
	DECLARE vAF_TOTAL_CUENTA VARCHAR(8);
	DECLARE vCVE_OPERACION VARCHAR(8);
    DECLARE vNoHandleRegistro BOOLEAN DEFAULT FALSE; 
	
	DECLARE cuOperacion 
    CURSOR FOR (
                SELECT AF_INVENTARIO, AF_TOTAL_CUENTA
                FROM operacion
                WHERE CVE_OPERACION = peCVE_OPERACION_OLD
		);
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET vNoHandleRegistro = TRUE;
	
    IF ((peSTATUS_OLD <> peSTATUS) AND (peSTATUS = 0)) THEN     
       OPEN cuOperacion;
       FETCH cuOperacion
       INTO vAF_INVENTARIO, vAF_TOTAL_CUENTA;
       IF NOT vNoHandleRegistro THEN
            IF (vAF_TOTAL_CUENTA = 'I') THEN 
				UPDATE cuenta SET IMP_TOTAL = (IMP_TOTAL - peIMP_TRANS_OLD)
                WHERE FOLIO = peFOLIO_OLD;
			ELSE
				IF (vAF_TOTAL_CUENTA = 'D') THEN 
					UPDATE cuenta SET IMP_TOTAL = (IMP_TOTAL + peIMP_TRANS_OLD)
                    WHERE FOLIO = peFOLIO_OLD;
                END IF;
            END	IF;
            IF ((vAF_INVENTARIO = 'I') OR (vAF_INVENTARIO = 'D')) THEN
				CALL StpInsBitInventario(peID_CONCEPTO_OLD, 
											'ECANCELA', 
                                            peCVE_USUARIO, 
                                            peCANTIDAD_OLD, 
                                            0,
                                            peTX_REFERENCIA, 
                                            peFOLIO_OLD,
                                            peID_ORDEN_DETALLE,
                                            vIdTransInventario,
                                            vCodResp,          
                                            vStrResp);
                                            
                                           
                                            
				IF (vCodResp <> 0) THEN
					SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =  vStrResp;
                END IF;
            END IF;
       END IF;
      CLOSE cuOperacion; 	    
    END IF; 
END;

