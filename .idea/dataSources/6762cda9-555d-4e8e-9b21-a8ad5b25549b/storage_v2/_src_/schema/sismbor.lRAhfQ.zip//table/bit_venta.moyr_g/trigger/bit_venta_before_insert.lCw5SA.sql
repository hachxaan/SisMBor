create definer = admin@`%` trigger bit_venta_BEFORE_INSERT
    before insert
    on bit_venta
    for each row
BEGIN

	CALL `trigger_BitVenta_BI`(
						NEW.FOLIO,
						NEW.ID_CONCEPTO,
						NEW.CANTIDAD,
						NEW.CVE_OPERACION,
						NEW.IMP_TRANS,
						NEW.CVE_USUARIO,
						NEW.TX_REFERENCIA,
                        NEW.ID_ORDEN_DETALLE,
                        NEW.ID_TRANS_INVENTARIO);
                        
END;

