create definer = admin@`%` trigger bit_venta_AFTER_UPDATE
    after update
    on bit_venta
    for each row
BEGIN
	CALL `trigger_BitVenta_AU`(
								OLD.ID_CONCEPTO,
                                OLD.CVE_OPERACION,
                                OLD.FOLIO,
                                OLD.IMP_TRANS,
                                NEW.CVE_USUARIO,
                                OLD.CANTIDAD,
                                NEW.TX_REFERENCIA,
                                NEW.STATUS,
                                OLD.STATUS,
                                OLD.ID_ORDEN_DETALLE);
END;

