create view w_hist_inventario as
select `b`.`ID_TRANS_INVENTARIO`                                                           AS `ID_TRANS_INVENTARIO`,
       `b`.`FH_REGISTRO`                                                                   AS `FH_REGISTRO`,
       (case
            when (`o`.`AF_INVENTARIO` = 'I') then 'ENTRADA'
            else (case when (`o`.`AF_INVENTARIO` = 'D') then 'SALIDA' else '-' end) end)   AS `AF_INVENTARIO`,
       `b`.`CANTIDAD`                                                                      AS `CANTIDAD`,
       `o`.`DESC_OPERACION`                                                                AS `DESC_OPERACION`,
       (case when (`b`.`CVE_OPERACION` = 'COMPRA') then `b`.`PRECIO_COMPRA` else NULL end) AS `PRECIO_COMPRA`,
       (case when (`o`.`AF_CAJA` = 'D') then `v`.`IMP_TRANS` else NULL end)                AS `DEVOL_EFECTIVO`,
       (case when (`o`.`AF_CAJA` = 'I') then `v`.`IMP_TRANS` else NULL end)                AS `PRECIO_VENTA`,
       `b`.`CVE_USUARIO`                                                                   AS `CVE_USUARIO`,
       ((0 <> `p`.`NOMBRE`) or (0 <> ' ') or (0 <> `p`.`APELLIDO`))                        AS `AGENTE`,
       `n`.`CVE_CONCEPTO`                                                                  AS `CVE_CONCEPTO`,
       `b`.`CVE_OPERACION`                                                                 AS `CVE_OPERACION`,
       `b`.`TX_REFERENCIA`                                                                 AS `TX_REFERENCIA`,
       `b`.`EXISTENCIA`                                                                    AS `EXISTENCIA`,
       `v`.`ID_PERSONAL`                                                                   AS `ID_PERSONAL`,
       `v`.`TIPO_VENTA`                                                                    AS `TIPO_VENTA`,
       `d`.`FOLIO`                                                                         AS `FOLIO`,
       `u`.`PLACA`                                                                         AS `PLACA`,
       (case when (`v`.`STATUS` = 0) then 'CANCELADO' else 'OK' end)                       AS `STATUS`,
       concat(`c`.`NOMBRE`, ' ', `c`.`APELLIDO`)                                           AS `NOMBRE_CLIENTE`
from ((((((((`sismbor`.`bit_inventario` `b` left join `sismbor`.`operacion` `o` on ((`o`.`CVE_OPERACION` = `b`.`CVE_OPERACION`))) left join `sismbor`.`bit_venta` `v` on ((`v`.`ID_TRANS_INVENTARIO` = `b`.`ID_TRANS_INVENTARIO`))) left join `sismbor`.`concepto` `n` on ((`n`.`ID_CONCEPTO` = `b`.`ID_CONCEPTO`))) left join `sismbor`.`orden` `d` on ((`d`.`FOLIO` = `v`.`FOLIO`))) left join `sismbor`.`unidad` `u` on ((`u`.`ID_UNIDAD` = `d`.`ID_UNIDAD`))) left join `sismbor`.`personal` `p` on ((`p`.`ID_PERSONAL` = `v`.`ID_PERSONAL`))) left join `sismbor`.`cuenta` `cta` on ((`cta`.`FOLIO` = `v`.`FOLIO`)))
         left join `sismbor`.`cliente` `c` on ((`c`.`ID_CLIENTE` = `u`.`ID_CLIENTE`)))
order by `b`.`ID_TRANS_INVENTARIO`;

