create
    definer = admin@`%` procedure trigger_BitInventario_AI(IN peID_CONCEPTO int, IN peCANTIDAD int,
                                                           IN peCVE_OPERACION varchar(32),
                                                           IN pePRECIO_COMPRA decimal(18, 2))
BEGIN
DECLARE vAF_INVENTARIO VARCHAR(5);
	DECLARE vCodResp INT;
	DECLARE vStrResp TEXT;

	DECLARE cuOperacion 
    CURSOR FOR (
                SELECT AF_INVENTARIO
                FROM operacion
                WHERE CVE_OPERACION = peCVE_OPERACION
                );
                
	OPEN cuOperacion;	
	FETCH cuOperacion INTO vAF_INVENTARIO;			 
	CLOSE cuOperacion;
	SET vStrResp = '';

    IF (vAF_INVENTARIO = 'I') THEN
		
        CALL StpActualizaConceptoStock('ENTRADA', peID_CONCEPTO, peCANTIDAD, vCodResp, vStrResp);
		IF (pePRECIO_COMPRA <> 0) AND (vCodResp = 0) THEN
			
			UPDATE concepto 
			SET PRECIO_COMPRA = pePRECIO_COMPRA
            WHERE ID_CONCEPTO = peID_CONCEPTO;
		END IF;
	END IF;
    IF (vAF_INVENTARIO = 'D') THEN
         CALL StpActualizaConceptoStock( 'SALIDA', peID_CONCEPTO, peCANTIDAD, vCodResp, vStrResp);
	END IF;    
	IF (vCodResp <> 0) THEN
		
		SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =  vStrResp;
	END IF;
END;

