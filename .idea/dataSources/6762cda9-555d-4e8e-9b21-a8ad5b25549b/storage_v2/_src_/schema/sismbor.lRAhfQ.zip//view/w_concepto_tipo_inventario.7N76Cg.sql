create view w_concepto_tipo_inventario as
select `sismbor`.`concepto_tipo`.`ID_TIPO_CONCEPTO`   AS `ID_TIPO_CONCEPTO`,
       `sismbor`.`concepto_tipo`.`DESC_TIPO_CONCEPTO` AS `DESC_TIPO_CONCEPTO`,
       `sismbor`.`concepto_tipo`.`CVE_OPERACION`      AS `CVE_OPERACION`,
       `sismbor`.`concepto_tipo`.`B_APLICA_COMISION`  AS `B_APLICA_COMISION`,
       `sismbor`.`concepto_tipo`.`CATEGORIA`          AS `CATEGORIA`,
       `sismbor`.`concepto_tipo`.`ACTIVO`             AS `ACTIVO`,
       `sismbor`.`operacion`.`DESC_OPERACION`         AS `DESC_OPERACION`,
       `sismbor`.`operacion`.`AF_TOTAL_CUENTA`        AS `AF_TOTAL_CUENTA`,
       `sismbor`.`operacion`.`AF_INVENTARIO`          AS `AF_INVENTARIO`,
       `sismbor`.`operacion`.`GPO_OPERACION`          AS `GPO_OPERACION`,
       `sismbor`.`operacion`.`AF_CAJA`                AS `AF_CAJA`,
       `sismbor`.`operacion`.`B_EFECTIVO`             AS `B_EFECTIVO`
from (`sismbor`.`concepto_tipo`
         left join `sismbor`.`operacion`
                   on ((`sismbor`.`operacion`.`CVE_OPERACION` = `sismbor`.`concepto_tipo`.`CVE_OPERACION`)));

