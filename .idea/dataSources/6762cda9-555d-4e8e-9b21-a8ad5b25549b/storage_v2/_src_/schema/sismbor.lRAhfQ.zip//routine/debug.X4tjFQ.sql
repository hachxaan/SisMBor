create
    definer = admin@`%` procedure debug(IN peTEXT text)
BEGIN 
 INSERT INTO `debug` (`TEXT`) VALUES (peTEXT); 
END;

