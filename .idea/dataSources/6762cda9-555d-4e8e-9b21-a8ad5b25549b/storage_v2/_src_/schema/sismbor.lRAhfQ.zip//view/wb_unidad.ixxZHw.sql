create view wb_unidad as
select `u`.`ID_UNIDAD`   AS `ID_UNIDAD`,
       `u`.`ID_CLIENTE`  AS `ID_CLIENTE`,
       `u`.`PLACA`       AS `PLACA`,
       `u`.`MARCA`       AS `MARCA`,
       `u`.`MODELO`      AS `MODELO`,
       `u`.`MOTOR`       AS `MOTOR`,
       `u`.`CHASIS`      AS `CHASIS`,
       `u`.`FH_REGISTRO` AS `FH_REGISTRO`
from `sismbor`.`unidad` `u`
where `u`.`ID_UNIDAD` in (select `sismbor`.`orden`.`ID_UNIDAD`
                          from `sismbor`.`orden`
                          where (`sismbor`.`orden`.`STATUS` in (0, 1))) is false;

