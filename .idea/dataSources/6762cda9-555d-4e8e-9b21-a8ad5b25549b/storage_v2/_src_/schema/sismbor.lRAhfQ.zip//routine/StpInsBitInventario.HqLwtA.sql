create
    definer = admin@`%` procedure StpInsBitInventario(IN peID_CONCEPTO int, IN peCVE_OPERACION varchar(128),
                                                      IN peCVE_USUARIO varchar(32), IN peCANTIDAD int,
                                                      IN pePRECIO_COMPRA decimal(18, 2),
                                                      IN peTX_REFERENCIA varchar(1024), IN peFOLIO int,
                                                      IN peID_ORDEN_DETALLE int, OUT psID_TRANS_INVENTARIO int,
                                                      OUT psCOD_RESP int, OUT psSTR_RESP varchar(1024))
StpMain:
BEGIN

	DECLARE vSTOCK INT;
    DECLARE vNoHandleRegistro			BOOLEAN DEFAULT FALSE; 

	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
        GET DIAGNOSTICS CONDITION 1 @sqlstate = RETURNED_SQLSTATE,
		 @errno = MYSQL_ERRNO, @text = MESSAGE_TEXT;
		SET @full_error = CONCAT("StpInsBitInventario: ERROR ", @errno, " (", @sqlstate, "): [", @text,"]");
         CALL `debug`(@full_error);
        SET psCOD_RESP = @errno;
		SET psSTR_RESP = substring( @text, 1, 1024 );
		IF psCOD_RESP = 1452 THEN
			SET psSTR_RESP = CONCAT('Error de llave foranea -> ','(Field:', SUBSTRING( psSTR_RESP, LOCATE('FOREIGN KEY (', psSTR_RESP) + 12,  100  ));
		END IF;
	END;    
	set psID_TRANS_INVENTARIO = 0;

	SELECT PRECIO_VENTA, STOCK
    INTO @V_PRECIO_VENTA, @V_STOCK
    FROM `concepto`
    WHERE ID_CONCEPTO = peID_CONCEPTO;
    
	INSERT INTO `bit_inventario` (
                                ID_CONCEPTO, 
                                CVE_OPERACION, 
								FOLIO,
                                CVE_USUARIO, 
                                CANTIDAD,
                                PRECIO_COMPRA,
                                TX_REFERENCIA,
                                PRECIO_VENTA,
                                EXISTENCIA,
                                ID_ORDEN_DETALLE
                                )
			VALUES (
						peID_CONCEPTO, 
						peCVE_OPERACION, 
                        peFOLIO,
						peCVE_USUARIO, 
						peCANTIDAD,
						pePRECIO_COMPRA,
                        peTX_REFERENCIA,
                        @V_PRECIO_VENTA,
                        @V_STOCK,
                        peID_ORDEN_DETALLE);
                        
	SELECT LAST_INSERT_ID() INTO @ID_TRANS_INVENTARIO;
    SET psID_TRANS_INVENTARIO = @ID_TRANS_INVENTARIO;
    
	
    SET psCOD_RESP = 0;
    SET psSTR_RESP = 'OK';

END StpMain;

