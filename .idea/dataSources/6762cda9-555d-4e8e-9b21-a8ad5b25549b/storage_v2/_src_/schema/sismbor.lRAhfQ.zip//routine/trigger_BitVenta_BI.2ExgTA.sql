create
    definer = admin@`%` procedure trigger_BitVenta_BI(IN peFOLIO int, IN peID_CONCEPTO int, IN peCANTIDAD int,
                                                      IN peCVE_OPERACION varchar(32), IN peIMP_TRANS decimal(18, 2),
                                                      IN peCVE_USUARIO varchar(32), IN peTX_REFERENCIA varchar(512),
                                                      IN peID_ORDEN_DETALLE int, OUT psID_TRANS_INVENTARIO int)
BEGIN
	DECLARE vCodResp INTEGER;
	DECLARE vStrResp VARCHAR(128);

	DECLARE  vIdTransInventario INT;
	DECLARE vPRECIO_VENTA DECIMAL(18,2);
	DECLARE  vAF_INVENTARIO VARCHAR(8);
	DECLARE  vAF_CAJA VARCHAR(8);
	DECLARE  vAF_TOTAL_CUENTA VARCHAR(8);
    DECLARE vNoHandleRegistro BOOLEAN DEFAULT FALSE; 
	
	DECLARE  vCVE_OPERACION VARCHAR(32);
	DECLARE  cuOperacion 
    CURSOR FOR (
                SELECT AF_INVENTARIO, AF_TOTAL_CUENTA, AF_CAJA
                FROM operacion
                WHERE CVE_OPERACION = vCVE_OPERACION
                );
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET vNoHandleRegistro = TRUE;
	SET vCVE_OPERACION = peCVE_OPERACION;
    -- CALL `debug`('trigger_BitVenta_AI -> StpInsBitInventario...');
   
	
    
  
    
    OPEN cuOperacion;
       FETCH cuOperacion
       INTO vAF_INVENTARIO, vAF_TOTAL_CUENTA, vAF_CAJA;
       IF NOT vNoHandleRegistro THEN
            IF (vAF_TOTAL_CUENTA = 'I') THEN
				SELECT PRECIO_VENTA INTO vPRECIO_VENTA
						FROM concepto WHERE ID_CONCEPTO = peID_CONCEPTO;
				UPDATE cuenta SET IMP_TOTAL = IMP_TOTAL + (peIMP_TRANS * peCANTIDAD)
                WHERE FOLIO = peFOLIO;
            ELSE
				IF (vAF_TOTAL_CUENTA = 'D') THEN
					UPDATE cuenta SET IMP_TOTAL = IMP_TOTAL -  (peIMP_TRANS * peCANTIDAD)
                    WHERE FOLIO = peFOLIO;
                END IF;
            END IF;
            IF (vAF_INVENTARIO <> 'N')  THEN

				CALL StpInsBitInventario(peID_CONCEPTO, 
									  peCVE_OPERACION, 
									  peCVE_USUARIO, 
									  peCANTIDAD,
									  vPRECIO_VENTA,
									  peTX_REFERENCIA, 
									  peFOLIO,
                                      peID_ORDEN_DETALLE,
                                      @ID_TRANS_INVENTARIO,
									  vCodResp,          
									vStrResp);
                IF (vCodResp = 0) THEN

                    SET psID_TRANS_INVENTARIO = @ID_TRANS_INVENTARIO;  

                ELSE
                 
					SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT =  vStrResp;
                  
                END IF;
            END IF; 
       END IF;
   CLOSE cuOperacion; 	
END;

