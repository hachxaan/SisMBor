create view w_concepto_detalle as
select `p`.`CVE_CONCEPTO`                                                                                       AS `CVE_CONCEPTO`,
       `p`.`ID_TIPO_SERVICIO`                                                                                   AS `ID_TIPO_SERVICIO`,
       `sismbor`.`tipo_servicio`.`DESC_TIPO_SERVICIO`                                                           AS `DESC_TIPO_SERVICIO`,
       `p`.`DESC_CONCEPTO`                                                                                      AS `DESC_CONCEPTO`,
       `t`.`DESC_TIPO_CONCEPTO`                                                                                 AS `DESC_TIPO_CONCEPTO`,
       (case
            when (`pc`.`DESC_CATEGORIA` is null) then `t`.`DESC_TIPO_CONCEPTO`
            else `pc`.`DESC_CATEGORIA` end)                                                                     AS `DESC_CATEGORIA`,
       `p`.`PRECIO_VENTA`                                                                                       AS `PRECIO_VENTA`,
       `p`.`ID_CATEGORIA`                                                                                       AS `ID_CATEGORIA`,
       `p`.`ID_TIPO_CONCEPTO`                                                                                   AS `ID_TIPO_CONCEPTO`,
       `p`.`CVE_USU_ALTA`                                                                                       AS `CVE_USU_ALTA`,
       concat(`p`.`CVE_CONCEPTO`, ' ', `p`.`DESC_CONCEPTO`, ' ', `t`.`DESC_TIPO_CONCEPTO`, ' ',
              `pc`.`DESC_CATEGORIA`)                                                                            AS `DESCRIPCION`,
       `p`.`CVE_CONCEPTO`                                                                                       AS `CLAVE_SEL`,
       `p`.`STOCK`                                                                                              AS `STOCK`,
       `o`.`AF_INVENTARIO`                                                                                      AS `AF_INVENTARIO`
from ((((`sismbor`.`concepto` `p` left join `sismbor`.`concepto_tipo` `t` on ((`t`.`ID_TIPO_CONCEPTO` = `p`.`ID_TIPO_CONCEPTO`))) left join `sismbor`.`tipo_servicio` on ((`sismbor`.`tipo_servicio`.`ID_TIPO_SERVICIO` = `p`.`ID_TIPO_SERVICIO`))) left join `sismbor`.`concepto_categoria` `pc` on ((`pc`.`ID_CATEGORIA` = `p`.`ID_CATEGORIA`)))
         left join `sismbor`.`operacion` `o` on ((`o`.`CVE_OPERACION` = `t`.`CVE_OPERACION`)))
order by `pc`.`DESC_CATEGORIA`, `p`.`DESC_CONCEPTO`;

